=== WP多说扩展 ===
Contributors: midoks@163.com
Donate link: https://me.alipay.com/midoks
Tags: duoshuo extend
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

"DUOHSUO"一个在wordpress上的留言插件,但是功能不能令我满意。
所以,我进行扩展开发,记录"DUOSHUO"留言用户的详细信息,和用户信息.让网站主,对自己用户很清楚。

== Description ==

"DUOHSUO" a message on a wordpress plugin, but the function is not to my satisfaction, 
so I extended the development, details recorded "DUOSHUO" message users, and user information. 
Allow site owners, for their users very clear.



== Installation ==

1. 上传到 `/wp-content/plugins/` 目录
2. 在后台插件菜单激活该插件


== Frequently asked questions ==
= 问题是无尽的 =
* 加我的QQ群:34063439
* 关注我的博客:midoks.cachecha.com

== Screenshots ==

1. 后台界面

== Changelog ==

= 0.1 =

* 后台
1. 查看多说访问记录
2. 用户详细信息
3. 删除单条信息
4. 删除全部信息
5. 清空所有数据

== Upgrade notice ==

= 0.1 =

* 后台
1. 查看多说访问记录
2. 用户详细信息
3. 删除单条信息
4. 删除全部信息
5. 清空所有数据

