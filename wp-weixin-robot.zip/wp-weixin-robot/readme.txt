=== wp-weixin-robot ===
Contributors: midoks@163.com
Donate link: https://me.alipay.com/midoks
Tags: weixin robot
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: weixin robot
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Weixin connected to the WordPress, use the information you faster

== Description ==

Weixin connected to the WordPress, use the information you faster

== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. 
2. 

== Changelog ==

1.由衷感谢你使用由midoks写的WP微信机器人插件
2.在此我非常感谢"飞说不可",没有你的捐助,这个插件还要等很久我才会写(基本上满足我的需求)
3.同时也感谢那些使用我的写的插件的人,没有你们的使用,我的劳作是没有意义的

0.修复图片随机问题("飞说不可"发现)
1.本次更新,最大亮点就是增加在后台操作和数据记录控制
2.也对服务号功能提供菜单管理功能
4.提供订阅事件提示
5.图片最优显示(图文消息)
6.是否开启测试模式(http://youdomain/?midoks&debug=1&kw=?)
7.解决图文显示BUG,中文名字不显示(2013-11-30)</p>
8.对各个事件进行了分离,如果你懂代码的,还是很好进行二次开发的.
9.增加关键字回复设置功能
10.对菜单设置功能,进行了大的更新.
11.增加了一个简单图形统计功能
12.添加了回复数字'0',返回分类信息


== Upgrade notice ==

你要知道微信是什么东西!!!

== Arbitrary section 1 ==

